#!/usr/local/bin/python3
#
# find_luddy.py : a simple maze solver
#
# Submitted by : [PUT YOUR NAME AND USERNAME HERE]
#
# Based on skeleton code by Z. Kachwala, 2019
#

import sys
import json
import time
from queue import PriorityQueue
# Parse the map from a given filename
def parse_map(filename):
    with open(filename, "r") as f:
        return [[char for char in line] for line in f.read().split("\n")]

# Check if a row,col index pair is on the map
def valid_index(pos, n, m):
    return 0 <= pos[0] < n  and 0 <= pos[1] < m

# Find the possible moves from position (row, col)
def moves(map, row, col):
    moves=((row+1,col), (row-1,col), (row,col-1), (row,col+1))

    # Return only moves that are within the board and legal (i.e. on the sidewalk ".")
    return [ move for move in moves if valid_index(move, len(map), len(map[0])) and (map[move[0]][move[1]] in ".@" ) ]

def heuristic_func(x,y):
    goal_loc=[(row_i,col_i) for col_i in range(len(IUB_map[0])-1) for row_i in range(len(IUB_map)) if IUB_map[row_i][col_i]=="@"][0]
    return abs(goal_loc[0]-x)+abs(goal_loc[1]-y)
# Perform search on the map
def fringe_get(fringe_elements):
    priority_list=[]
    for i in fringe_elements:
        priority_list.append(i[1])
    priority_list.sort()
    for i in range (0,len(fringe_elements)):
        if(fringe_elements[i][1]==priority_list[0]):
            popped_element=fringe_elements.pop(i)
            
            return (popped_element[0],popped_element[2])

def getCompassDirections(last_location,current_location):
    path_till_now=last_location[1]
    #print(last_location)
    #print(current_location)
    if(last_location[0][0]==current_location[0]):
        if(last_location[0][1]<current_location[1]):
            return path_till_now+"E"
        else:
            return path_till_now+"W"
    elif(last_location[0][1]==current_location[1]):
        if(last_location[0][0]<current_location[0]):
            return path_till_now+"S"
        else:
            return path_till_now+"N"


def search1(IUB_map):
    # Find my start position
    you_loc=[(row_i,col_i) for col_i in range(len(IUB_map[0])-1) for row_i in range(len(IUB_map)) if IUB_map[row_i][col_i]=="#"][0]
    fringe=[(you_loc,0,"")]
    #came_from={}  #Created this map to keep track of the source states
    cost_so_far={}  #Created this map to keep track of the path cost and the visited states
    #came_from[you_loc]=None 
    cost_so_far[you_loc]=0
    temp=[]
    temp.append([you_loc,0])
    while len(fringe)!=0:
        curr_move=fringe_get(fringe)
        if(IUB_map[curr_move[0][0]][curr_move[0][1]]=="@"):
            #print("Cost so far- "+str(cost_so_far))
#            print("Came from- "+str(came_from))
            return cost_so_far[curr_move[0]],curr_move[1]
        for move in moves(IUB_map, *curr_move[0]):  #Iterating through successor states
            new_cost=cost_so_far[curr_move[0]]+1
            if(move not in cost_so_far or new_cost<cost_so_far[move]):
                cost_so_far[move]=new_cost
                priority=new_cost+heuristic_func(*move)
                directions=getCompassDirections(curr_move,move)
                fringe.append((move,priority,directions))
                temp.append([move,priority])
                #came_from[move]=curr_move
    #print("The value in temp variable is- "+str(temp))
    #print("Cost so far- "+str(cost_so_far))
    #print("Came from- "+str(came_from))
    return "Inf",""

# Main Function
if __name__ == "__main__":
    IUB_map=parse_map(sys.argv[1])
    print("Shhhh... quiet while I navigate!")
    print(IUB_map)
    solution = search1(IUB_map)
    print("Here's the solution I found:")
    print(solution)
    #print(cost)

