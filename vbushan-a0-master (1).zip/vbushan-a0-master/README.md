# a0

Question 1
Problem Statement- 
To reach a goal location along the shortest path, while avoiding the obstacles, in a map given to the user.

Implementation:
I used the A* search algorithm, which uses a cost function and heuristic function to distinguish between states and helps in navigating along the shortest route.
f(s)=g(s)+h(s)

where,
f(s)=cost function
g(s)=distance covered
h(s)=heuristic function
For this problem, the heuristic function is a measure of Manhattan distance of a state from the goal state.

The search abstraction which I used to implement this algorithm is as follows-

•	Initial location of the user.
•	Defined a fringe, which acts like a priority queue.
•	Defined a map which keeps track of the cost to reach a particular node.
•	 Repeat:
o	If fringe==empty, then return Failure
o	Remove(fringe)=s
o	If s==goal state, then return the cost and directions.
o	Else, for every s’ in Succ(s):
	Calculate the cost required to reach the successor state
	If the successor state is not in the cost map, add the state in the fringe (which is a priority queue) after calculating the heuristic function, and add the sum of cost and heuristic function as the priority.
If there exists no solution, the fringe would be empty, and the algorithm would return no solution.

Additional function definitions:
•	fringe_get(fringe_elements): I added this function so that the node with the highest priority is removed first from the fringe.
•	getCompassDirections(last_location,current_location): I added this function so that I convert the subsequent moves into compass directions.(E,W,N,S)

Output in the local Machine for the given map.
Shhhh... quiet while I navigate!
[['.', '.', '.', '.', '&', '&', '&'], ['.', '&', '&', '&', '.', '.', '.'], ['.', '.', '.', '.', '&', '.', '.'], ['.', '&', '.', '&', '.', '.', '.'], ['.', '&', '.', '&', '.', '&', '.'], ['#', '&', '.', '.', '.', '&', '@']]
Run Time- 0.0
Here's the solution I found:
16 NNNEESSSEENNEESS

Question 2:

Problem Statement
To arrange the K (user input) new friends, who do not like each other, on the map which we used in the last question.

Implementation:
 I used the Depth First Search algorithm to solve this problem. The following is the search abstraction of the algorithm-

•	Parse the initial map
•	Defined a fringe. (Stack)
•	Add the initial map to the fringe
•	Repeat:
o	Return failure if fringe is empty
o	Remove the last element from the fringe
o	Calculated the successor states of the element removed.
o	Check if the successor states of the removed element is the goal state
o	If a successor state is not equal to goal state add to the fringe.

Modified function definitions:
successors(board):
Modified this function to check and add only if the successor state returned by the add_friend method is valid. 

Additional function definitions
check(board):
Added this method to check if the board rendered by the add_friend method is valid. Used regular expressions for validating the map.




